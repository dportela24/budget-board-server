const mongoose = require('mongoose')

const incomeSchema = new mongoose.Schema({
    description: {
        type: String,
        required: true,
        trim: true
    },
    value: {
        type: Number,
        required:true
    }
}, 
    {
        timestamps: true,
    }
);

incomeSchema.methods.toJSON = function () {
    const userObject = this.toObject();
    userObject.type = 'income';

    return userObject;
}

const Income = mongoose.model('Income', incomeSchema);

module.exports = Income;