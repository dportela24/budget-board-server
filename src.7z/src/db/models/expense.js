const mongoose = require('mongoose')

const expenseSchema = new mongoose.Schema({
    description: {
        type: String,
        required: true,
        trim: true
    },
    value: {
        type: Number,
        required:true
    },
},
    {
        timestamps: true
    }
);

expenseSchema.methods.toJSON = function () {
    const userObject = this.toObject();
    userObject.type = 'expense';

    return userObject;
}

const Expense = mongoose.model('Expense', expenseSchema);

module.exports = Expense;