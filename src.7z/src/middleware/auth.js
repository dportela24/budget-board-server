const jwt = require('jsonwebtoken')
const User = require('../db/models/user')

const auth = async (req, res, next) => {
    try {
        const token = req.cookies['jwt']

        const user = await getUserFromToken(token)
        if (!user)
        {
            throw new Error('Authentification failed.')
        }

        req.token = token
        req.user = user

        next();
    } catch (e) {
        console.log(e);
        res.status(401).redirect('/')
    }
}

const getUserFromToken = async (token) => {
    if (!token)
    {
        return undefined
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET)

    const user = await User.findOne({ _id: decoded._id, 'tokens.token': token })

    return user
}

const isTokenValid = async (token) => {
    try {
        const user = await getUserFromToken(token)
        
        return user ? true : false;
    } catch (e) {
        return false;
    }
}

module.exports = {
    auth,
    isTokenValid,
}