const express = require('express')
const Expense = require('../db/models/expense')
const {auth} = require('../middleware/auth')

const router = express.Router();

router.get('/expense', auth, async (req, res) => {
    try {
        const user = req.user;
        const sortMethod = req.query.sortMethod;

        await user.populate({
            path: 'expenses', 
            options: {
                sort: { 
                    sortMethod : -1 
                }
            }
        }).execPopulate();

        const expenses = user.expenses;

        res.send(expenses);
    }catch (e) {
        res.status(500).send(e);
    }
})

router.post('/expense', auth, async (req, res) => {
    try {
        const user = req.user;
        const expense = new Expense(req.body);

        await expense.save();

        user.expenses.push(expense);
        user.save();

        res.status(201).send(expense)
    } catch (e) {
        res.status(400).send(e)
    }
})

router.delete('/expense', auth, async (req, res) => {
    try {
        const user = req.user;
        const expense = await Expense.findByIdAndDelete(req.body._id);

        res.send(expense);
        
        user.removeExpense(req.body._id); 
        user.save();

    } catch (e) {
        console.log(e)
        res.status(500).send(e);
    }
})

module.exports = router