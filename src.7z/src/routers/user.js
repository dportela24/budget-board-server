const express = require('express')
const path = require('path')
const User = require('../db/models/user')
const {auth, isTokenValid} = require('../middleware/auth')

const router = express.Router()

router.get('/', async (req, res) => {
    try {
        const token = req.cookies['jwt']
        if (await isTokenValid(token)) {
            res.redirect('/wallet')
        } else {
            res.sendFile(path.join(__dirname, '../../public/loginPage/login.html'))
        }
    } catch {
        res.sendFile(path.join(__dirname, '../../public/loginPage/login.html'))
    }
})

router.get('/me', auth, (req,res) => {
    res.send(req.user);
})

router.post('/login', async (req, res) => {
    try {
        const user = await User.findByCredentials(req.body.username, req.body.password)

        const token = user.generateAuthToken()

        await user.save()
        
        res.cookie('jwt', token, { httpOnly: true })
        res.send()
    } catch (e) {
        console.log(e)
        res.status(400).send(e) 
    }
}) 

router.post('/logout', auth, async (req, res) => {
    try {
        const user = req.user;
        req.user.removeAuthToken(req.token);
        user.save()
    } catch (e) {
        res.status(401).send(4);
    }
})

router.get('/signin', (req, res) => {
    res.sendFile(path.join(__dirname, '../../public/signinPage/signin.html'))
})

router.post('/signin', async (req, res) => {
    try {
        const user = new User(req.body)

        const token = user.generateAuthToken()

        await user.save()

        res.cookie('jwt', token, { httpOnly: true })
        res.status(201).send()
    } catch (e) {
        console.log(e)
        res.status(400).send(e)
    }
})

module.exports = router