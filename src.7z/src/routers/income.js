const express = require('express');
const {auth} = require('../middleware/auth')
const Income = require('../db/models/income');

const router = express.Router();

router.get('/income', auth, async (req, res) => {
    try {
        const user = req.user;
        const sortMethod = req.query.sortMethod;


        await user.populate({
            path: 'incomes', 
            options: {
                sort: { 
                    sortMethod : -1 
                }
            }
        }).execPopulate();
        
        const incomes = user.incomes;
        
        res.send(incomes);
    } catch (e) {
        console.log(e)
        res.status(500).send(e);
    }
})

router.post('/income', auth, async (req, res) => {
    try {
        const user = req.user;
        const income = new Income(req.body);

        await income.save();

        user.incomes.push(income);
        user.save();
    
        res.status(201).send(income)
    } catch (e) {
        console.log(e)
        res.status(400).send(e)
    }
})

router.delete('/income', auth, async (req, res) => {
    try {
        const user = req.user;
        const income = await Income.findByIdAndDelete(req.body._id);
        if (!income) {
            res.status(404).send();
        }
        
        res.send(income);

        user.removeIncome(req.body._id);
        user.save();
    } catch (e) {
        res.status(500).send(e);
    }
})

module.exports = router;